-- DropIndex
DROP INDEX "UserSchema_key_key";
